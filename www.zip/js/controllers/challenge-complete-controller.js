angular.module('starter')

.controller('challenge-complete-controller', function($scope) {

});