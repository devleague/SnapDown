angular.module('starter')

.controller('landing-controller', function($scope) {

});