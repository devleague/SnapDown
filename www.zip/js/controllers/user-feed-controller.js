angular.module('starter')

.controller('user-feed-controller', function($scope) {

});
