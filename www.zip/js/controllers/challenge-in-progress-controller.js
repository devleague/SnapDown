angular.module('starter')

.controller('challenge-in-progress-controller', function($scope) {

});