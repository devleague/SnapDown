angular.module('starter')

.controller('select-challenger-controller', function ($scope, UserService, ChallengeService, $stateParams) {

  $scope.imageURI = $stateParams.imageURI;

  $scope.UserService = UserService;
  $scope.users = [];

  $scope.getAllUsers = function(){
    UserService.getAllUsers()
    .success(function (res){
      $scope.users = res;
    })
    .error(function (err){
      console.log('Error with receiving users', err);
    })
  };

  $scope.addUserToChallenge = function (){
    ChallengeService.addUserToChallenge()
    .success(function (res){
      console.log('user added to challenge', res)
    })
    .error(function (err){
      console.log('Error with adding user', err);
    })
  };

  $scope.removeUserFromChallenge = function (){
    ChallengeService.removeUserFromChallenge()
    .success(function (res){
      console.log(res)
    })
    .error(function (err){
      console.log('Error with removing user', err);
    })
  };

  $scope.createNewChallenge = function (){
    ChallengeService.createNewChallenge()
    .success(function (res){
      console.log('challenge created', res)
      //forward to the in progress page
    })
    .error(function (err){
      console.log('Error with creating a challenge', err);
    })
  };

});