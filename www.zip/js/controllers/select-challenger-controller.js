angular.module('starter')

.controller('select-challenger-controller', function($scope) {
});