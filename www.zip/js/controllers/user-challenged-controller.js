angular.module('starter')

.controller('detail-view-controller', function($scope) {

});
